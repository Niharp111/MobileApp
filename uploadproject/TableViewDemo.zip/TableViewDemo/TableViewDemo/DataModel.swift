//
//  DataModel.swift
//  TableViewDemo
//
//  Created by Student on 3/31/17.
//  Copyright © 2017 Student. All rights reserved.
//

import Foundation

class DataModel {
    
    var data:[String]?
    
    
}
