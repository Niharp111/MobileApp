//
//  ViewController.swift
//  MapKitExample
//
//  Created by Student on 3/22/17.
//  Copyright © 2017 Janki Patel. All rights reserved.
//

import UIKit
import CoreLocation
import MapKit

class ViewController: UIViewController, MKMapViewDelegate {

    var locationManager: CLLocationManager?
    @IBOutlet weak var mapView: MKMapView?
    
    
    required init?(coder aDecoder:NSCoder) {
        
        locationManager = CLLocationManager()
        if CLLocationManager.locationServicesEnabled() {
        locationManager!.requestWhenInUseAuthorization()
            
        }
        
        super.init(coder: aDecoder)
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        mapView?.delegate = self
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func mapView(_ mp: MKMapView, didUpdate userLocation: MKUserLocation) {
        
        //add an annotation 
        let point = MKPointAnnotation()
        point.coordinate = userLocation.coordinate
        point.title = "Where am I?"
        point.subtitle = "I am here!"
        
        mapView?.addAnnotation(point)
        
        let mkCoordinateRegion = MKCoordinateRegionMakeWithDistance(userLocation.coordinate, 800, 800)
        self.mapView?.setRegion(mkCoordinateRegion, animated: true)
        
    }

}

