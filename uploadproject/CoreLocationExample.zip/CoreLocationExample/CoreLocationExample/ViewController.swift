//
//  ViewController.swift
//  CoreLocationExample
//
//  Created by Student on 3/20/17.
//  Copyright © 2017 Student. All rights reserved.
//

import UIKit
import CoreLocation

class ViewController: UIViewController, CLLocationManagerDelegate {

    @IBOutlet weak var latitude: UILabel!
    
    @IBOutlet weak var longitude: UILabel!
    
    
    @IBOutlet weak var altitude: UILabel!
    
    
    @IBOutlet weak var hAccuracy: UILabel!
    
    @IBOutlet weak var vAccuracy: UILabel!
    
    
    @IBOutlet weak var timestamp: UILabel!
    
    
    @IBOutlet weak var speed: UILabel!
    
    
    @IBOutlet weak var course: UILabel!
    
    var locationManager = CLLocationManager()
    var location:CLLocation?
    var geocoder = CLGeocoder()
    var placemark: CLPlacemark?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        if CLLocationManager.locationServicesEnabled(){
            if locationManager.responds(to: #selector(CLLocationManager.requestWhenInUseAuthorization)) {
                locationManager.requestAlwaysAuthorization()
            }
        }
          locationManager.desiredAccuracy = kCLLocationAccuracyBest
          locationManager.startUpdatingLocation()
          locationManager.delegate = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        switch status {
        case .authorizedAlways:
            locationManager.startUpdatingLocation()
        case .notDetermined:
            locationManager.requestAlwaysAuthorization()
        case .authorizedWhenInUse, .restricted, .denied:
            
            let alertController = UIAlertController(title: "Background Location Access Disabled", message: "In order to keep updatng your location for this app, please open this app's settings and set location access to 'Always'", preferredStyle: .alert)
            
            let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
            alertController.addAction(cancelAction)
            
            let openAction = UIAlertAction(title: "Open Settings", style: .default) {(action) in
                
                if let url = URL(string: UIApplicationOpenSettingsURLString) {
                    UIApplication.shared.open(url, options: [:], completionHandler: nil)
                    
                }
        }
            alertController.addAction(openAction)
            present(alertController, animated: true, completion: nil)
    }
}
    
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        location = locations.last
        print("\(location)")
        latitude.text = String(format: "%.4f", location!.coordinate.latitude)
        longitude.text = String(format: "%.4f", location!.coordinate.longitude)
        altitude.text = String(format: "%.4f", location!.altitude)
        latitude.text = String(format: "%.4f", location!.coordinate.latitude)
        hAccuracy.text = String(format: "%.4f", location!.horizontalAccuracy)
        vAccuracy.text = String(format: "%.4f", location!.verticalAccuracy)
        timestamp.text = "\(location!.timestamp)"
        speed.text = String(format: "%.4f", location!.speed)
        course.text = String(format: "%.4f", location!.course)
        locationManager.stopUpdatingLocation()
        
        //reverse geocoding
        geocoder.reverseGeocodeLocation(location!, completionHandler: {(placemarks, error)->Void in
           print(self.location!)
            if error != nil {
                print("Reverse geocoder failed with error \(error!.localizedDescription)")
                return
            }
            if placemarks!.count > 0 {
                let pm = placemarks!.last
                let address = "\(pm!.subThoroughfare) \(pm!.thoroughfare)\n\(pm!.postalCode)\n\(pm!.subAdministrativeArea)\n\(pm!.administrativeArea)\n\(pm!.subLocality)\n\(pm!.locality)\n\(pm!.country)\n\(pm!.isoCountryCode)"
                print(address)
            } else{
                print("reverse geocoding couldn't find an address")
            }
        })
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        let errorAlert = UIAlertController(title: "Error", message: "Failed to get your location", preferredStyle: .alert)
        let OKAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        errorAlert.addAction(OKAction)
        present(errorAlert, animated: true, completion: nil)
        
    }
   
}

