//  FavoritePlaces
//
//  Created by Bryan French on 7/31/15.
//  Copyright (c) 2015 Bryan French. All rights reserved.
//

import UIKit
import MapKit

class MapVC: UIViewController, MKMapViewDelegate,ZoomingProtocol {
    
    @IBOutlet weak var mapView : MKMapView!
    
    var landmarkList = Landmarks()
    var landmarks : [Landmark] { //front end for LandmarkList model object
        get {
            return self.landmarkList.landmarkList
        }
        set(val) {
            self.landmarkList.landmarkList = val
        }
    }
    
    //func zoomOn(annotation:MKAnnotation) - swift 3 way
    func zoomOnAnnotation(_ annotation:MKAnnotation){
        
        tabBarController?.selectedViewController = self
        
        // zoom in
        let region = MKCoordinateRegionMakeWithDistance(annotation.coordinate, 250, 250)
        mapView.setRegion(region, animated: true)
        
        mapView.selectAnnotation(annotation, animated: true)
        
    }
    
    
    // this method called once for every annotation created
    // if no views return than only defalut pin is seen
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        var view:MKPinAnnotationView
        let identifier = "Pin"
        
        if annotation is MKUserLocation {
            return nil //  so map will drew default blue dot
        }
        
        if annotation !== mapView.userLocation {
            // look for existing view to reuse
            if let dequeuedView=mapView.dequeueReusableAnnotationView(withIdentifier: identifier) as? MKPinAnnotationView {
                dequeuedView.annotation = annotation
                view = dequeuedView
                } else {
                //no vieew to reuse. create one
                view = MKPinAnnotationView(annotation: annotation, reuseIdentifier: identifier)
                
                //customize it
                view.pinTintColor = MKPinAnnotationView.purplePinColor()
                view.animatesDrop = true
                view.canShowCallout = true
                
                let leftButton = UIButton(type:  .infoLight)
                let rightButton = UIButton(type: .detailDisclosure)
                leftButton.tag = 0
                rightButton.tag = 1
                view.leftCalloutAccessoryView = leftButton
                view.rightCalloutAccessoryView = rightButton
            }
            return view
        }
        return nil
    }
    
    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
        let annoation = view.annotation
        print("The title of the annotation is \(annoation!.title)")
    }

    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
        print("Control tapped: \(control), tag numer = \(control.tag)")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
      
        let np = NorthPole()
        mapView.addAnnotation(np)
        mapView.delegate = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        for landmark: MKAnnotation in landmarks {
            mapView.addAnnotation(landmark)
        }
    }


}

