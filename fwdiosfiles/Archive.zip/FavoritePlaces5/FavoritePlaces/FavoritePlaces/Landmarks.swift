//
//  Landmarks.swift
//  FavoritePlaces
//
//  Created by Bryan French on 7/31/15.
//  Copyright (c) 2015 Bryan French. All rights reserved.
//

import Foundation

//Array pass by value in struct

class Landmarks {
    var landmarkList : [Landmark] = []
}
