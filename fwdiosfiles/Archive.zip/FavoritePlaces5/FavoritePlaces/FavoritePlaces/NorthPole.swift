//
//  NorthPole.swift
//  FavoritePlaces
//
//  Created by Student on 3/29/17.
//  Copyright © 2017 Student. All rights reserved.
//

import Foundation
import CoreLocation
import MapKit

class NorthPole:NSObject,MKAnnotation {
    
    //Needed for MKAnnotation Protocol
    var coordinate: CLLocationCoordinate2D {
        get{
            return CLLocationCoordinate2DMake(88, 0)
        }
    }
    
    var title:String? {
        get {
            return "The North Pole"
        }
    }
    
    var subtitle: String? {
        get {
            return "Santa's Workshop"
        }
    }
    
    
}
