//
//  ZoomingProtocol.swift
//  FavoritePlaces
//
//  Created by Student on 4/12/17.
//  Copyright © 2017 Student. All rights reserved.
//

import Foundation
import MapKit
protocol ZoomingProtocol {
    func zoomOnAnnotation(_ annotation:MKAnnotation)
}
