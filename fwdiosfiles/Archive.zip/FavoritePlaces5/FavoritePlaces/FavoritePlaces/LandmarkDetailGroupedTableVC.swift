//
//  LandmarkDetailGroupedTableVC.swift
//  FavoritePlaces
//
//  Created by Student on 4/10/17.
//  Copyright © 2017 Student. All rights reserved.
//

// create swift file for only constant

import UIKit

class LandmarkDetailGroupedTableVC: UITableViewController {

    var landmark:Landmark!
    //var mapVC:MapVC!
    var zoomDelegate: ZoomingProtocol?
    
    let LANDMARK_SECTION = 0
    let STATE_SECTION = 1
    let COORDINATE_SECTION = 2
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 3
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 1
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
     // we are not using story board so no need
        //let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)
        
        var cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier")

        if !(cell != nil) {
                cell = UITableViewCell(style: .default, reuseIdentifier: "reuseIdentifier")
        }
        
        // Configure the cell...
        
        switch indexPath.section{
        case LANDMARK_SECTION:
            cell?.textLabel?.text = landmark.name
        case STATE_SECTION:
            cell?.textLabel?.text = landmark.state
        case COORDINATE_SECTION:
            cell?.textLabel?.text = "Latitude: \(landmark.coordinate.latitude), Longitude: \(landmark.coordinate.longitude)"
        default:
            break;
        }
        cell?.textLabel?.numberOfLines = 0
        return cell!
    }
    
    override func tableView(_ tableView: UITableView, titleForFooterInSection section: Int) -> String? {
        var title = ""
        switch section{
        case LANDMARK_SECTION:
            title = "Landmark Name"
        case STATE_SECTION:
            title = "Landmark State"
        case COORDINATE_SECTION:
            title = "Landmark Coordinates"
        default:
            break;
        }
        return title
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == COORDINATE_SECTION {
            return 88.0
        } else {
            return 44.0
        }
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        var msg = ""
        switch indexPath.section{
        case LANDMARK_SECTION:
            msg = "You Tapped Landmark Name"
        case STATE_SECTION:
            msg = "You Tapped Landmark State"
        case COORDINATE_SECTION:
            msg = "You Tapped Landmark Coordinates"
            
            // the worst way 1st
            
                // get app delegate
                /*
                let appDel = UIApplication.shared.delegate as! AppDelegate
                (appDel.tabBarController?.viewControllers![0] as! MapVC).zoomOnAnnotation(landmark)
                */
            
            // a little better
                //(tabBarController?.viewControllers![0] as! MapVC).zoomOnAnnotation(landmark)
            
            //mapVC.zoomOnAnnotation(landmark)
            
            zoomDelegate?.zoomOnAnnotation(landmark)
            
        default:
            break;
        }
        
        /*
        let alert = UIAlertController(title: "Tapped a Row", message: msg, preferredStyle: .alert)
        let OKAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alert.addAction(OKAction)
        present(alert, animated: true, completion: nil)
        */
        
        tableView.deselectRow(at: indexPath, animated: true)
    }

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
